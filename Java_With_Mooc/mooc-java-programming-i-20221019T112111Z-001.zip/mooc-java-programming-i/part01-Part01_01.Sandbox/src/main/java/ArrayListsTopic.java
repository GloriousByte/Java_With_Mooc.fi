import java.util.ArrayList;
public class ArrayListsTopic {
    
    ArrayList <String> list  = new ArrayList<>();


}
