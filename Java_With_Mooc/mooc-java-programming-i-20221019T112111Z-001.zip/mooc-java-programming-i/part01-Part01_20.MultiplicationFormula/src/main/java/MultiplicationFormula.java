
import java.util.Scanner;

public class MultiplicationFormula {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.println("Give the first");
        int first = Integer.valueOf(scanner.nextLine());
        System.out.println("Give the second");
        int second = Integer.valueOf(scanner.nextLine());
        System.out.println(first+ "x"+ second + "="+ (first * second));

    }
}
